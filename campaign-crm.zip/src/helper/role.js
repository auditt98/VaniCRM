export const Role = {
    Admin: 3,
    User: 'User'
}