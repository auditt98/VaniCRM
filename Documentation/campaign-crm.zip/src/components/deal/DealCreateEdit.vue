<template>
<div></div>
</template>

<script>
export default {
  name: "DealCreateEdit"
}
</script>

<style scoped>

</style>